sudo apt install fonts-noto-color-emoji
sudo apt install python3-webview
sudo apt install python3-requests
