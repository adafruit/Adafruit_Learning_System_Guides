# LUNA TRANSIT — hardware build

Flight tracker that filters to planes likely to cross the moon, for the
**Adafruit Qualia ESP32-S3 + 2.1" round 480×480 touch TFT** (product 5792).

## Install

1. Flash CircuitPython 9.x for **Qualia ESP32-S3 RGB666**.
2. Copy to `CIRCUITPY/`:
   - `code.py`
   - `moon_ephem.py`
   - `settings.toml` (from `settings.toml.example`, with your WiFi creds)
3. Copy these libraries from the CircuitPython bundle into `CIRCUITPY/lib/`:
   - `adafruit_qualia/` (handles round-TFT init + CST8xx touch)
   - `adafruit_display_text/`
   - `adafruit_requests.mpy`
   - `adafruit_connection_manager.mpy`
   - `adafruit_ntp.mpy`
   - anything `adafruit_qualia` pulls in (`adafruit_focaltouch` / touch driver per its docs)

## Data sources (no API keys)

- **Aircraft**: `opendata.adsb.fi/api/v2/lat/…/lon/…/dist/15` every 8 s
- **Location**: zip → lat/lon via `api.zippopotam.us` (saved to NVM)
- **Moon**: computed on-device (`moon_ephem.py`, ~0.3° accuracy), NTP for time

## How it decides "transit candidate"

Each plane is stepped forward 5 min along its track/groundspeed; its az/el
(from your location, using baro altitude) is compared against the moon's
az/alt. Minimum angular separation < **2°** ⇒ candidate; banner + pink bezel
ring when ETA ≤ 90 s. The moon disc is 0.52°, so tighten `ALERT_SEP_DEG`
once you trust your location/lens setup.

## UI map (matches the design prototype)

- **RAD** — radar, moon hero at its azimuth, filter chip toggles 5 mi ↔ 300 mm (3.1 mi)
- **LIST** — candidates sorted by separation, ETA to closest approach
- **MOON** — phase render, illumination %, alt/az
- **LOC** — zip keypad, OK geocodes + persists

## Knobs (top of code.py)

`FETCH_S`, `LOOKAHEAD_S`, `ALERT_SEP_DEG`, `NM_RADIUS`, `PX_PER_MI`

## Untested-on-hardware notes

- Touch API: written against `graphics.touch.touched` / `.touches[0]["x"]` —
  check the adafruit_qualia examples for your board rev and adjust
  `handle_touch()` polling if the attribute names differ.
- If you hit memory pressure, drop label count on the radar (skip altitude
  labels) or raise `FETCH_S`.
- HTTPS to adsb.fi + zippopotam requires correct time; NTP runs at boot.
