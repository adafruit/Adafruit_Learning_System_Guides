# Adafruit PyCamera Library [![Build Status](https://github.com/adafruit/Adafruit_PyCamera/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_PyCamera/actions) [![Documentation](https://github.com/adafruit/ci-arduino/blob/master/assets/doxygen_badge.svg)](http://adafruit.github.io/Adafruit_PyCamera/html/index.html)

This is a library for the Adafruit MEMENTO:
  * [https://www.adafruit.com/products/5420](https://www.adafruit.com/product/5420)

Adafruit invests time and resources providing this open source code, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Written by ladyada for Adafruit Industries.

MIT license, check license.txt for more information All text above must be included in any redistribution

To install, use the Arduino Library Manager and search for "Adafruit PyCamera" and install the library.
